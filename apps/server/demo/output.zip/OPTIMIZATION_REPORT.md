# Gas Optimization Report — Level 1

**Scope:** `src/Airdrop.sol`, `src/StakingPool.sol`  
**Output:** `optimized/src/Airdrop.sol`, `optimized/src/StakingPool.sol`  
**Level:** 1 only — function-body transforms; storage layout and external ABI unchanged  
**Build:** `forge build --contracts optimized/src` → clean (0 errors, 2 pre-existing test warnings)  
**Verification gate:** `forge test` / fuzzing skipped per user instructions

---

## Pattern reference key

| Tag | Pattern |
|-----|---------|
| A   | Custom errors (4-byte selector vs. ABI-encoded `require` string) |
| Q   | Cache repeated SLOADs; hoist loop-invariant reads out of loops |
| R   | `constant` / `immutable` for never-reassigned values |
| S   | `calldata` instead of `memory` for read-only external params |
| T   | `public` → `external` on functions never called internally |
| U   | Remove redundant `== true` / `== false` comparisons; fail-fast ordering |
| W   | Named return variable (drops one local + explicit `return`) |
| X   | Cache array `.length`; `unchecked { ++i }` counter |
| Y   | Drop explicit default initialisation (`uint256 x = 0` → `uint256 x`) |

---

## Airdrop.sol

### State variables

| Variable | Before | After | Rationale |
|----------|--------|-------|-----------|
| `name` | `string public` (storage slot) | `string public constant` | Never reassigned. Each SLOAD avoided saves ~2100 gas (cold) / ~100 gas (warm). |
| `claimFeeBps` | `uint256 public` (storage slot) | `uint256 public constant` | Always 0, never reassigned. Eliminates storage slot. |
| `owner` | `address public` (storage slot) | `address public immutable` | Set only in constructor. Reads go from ~2100 gas SLOAD to a bytecode PUSH. |

### `setAllocations` (Patterns T, S, X, Y, Q, A, U)

- **T:** `public` → `external`
- **S:** `address[] memory, uint256[] memory` → `calldata` — avoids full ABI-decode copy on entry
- **A:** `require(users.length == amounts.length, long string)` → `if (...) revert LengthMismatch()` / `revert ZeroAmount()`
- **X:** `uint256 len = users.length` hoisted before loop; `i++` → `unchecked { ++i }`
- **Y:** `for (uint256 i = 0; ...)` → `for (uint256 i; ...)`
- **Q (high value):** `totalAllocated` was read AND written inside every iteration. Now one SLOAD before the loop and one SSTORE after → saves `(N-1)` warm SSTOREs (~2900 gas each for non-zero→non-zero) per call with N users
- **U:** `isRegistered[user] == false` → `!isRegistered[user]`

### `claim` (Patterns T, A, U)

- **T:** `public` → `external`
- **A:** All three `require` strings replaced with custom errors
- **U:** `hasClaimed[msg.sender] == false` → `!hasClaimed[msg.sender]`
- **Y:** `require(amount > 0, ...)` → `if (amount == 0) revert NoAllocation()` (semantically identical, cheaper revert path)

### `totalUnclaimed` (Patterns T, W, X, Y, Q)

- **T:** `public` → `external`
- **W:** Named return `uint256 total` eliminates `return total` statement
- **Y:** `uint256 total = 0` → `uint256 total`
- **X:** Hoist `recipients.length` to `len`; `i++` → `unchecked { ++i }`
- **Q:** `address r = recipients[i]` cached — `recipients[i]` was read once in the condition and once in the sum, now one SLOAD. Also use `Allocation storage a = allocations[r]` pointer so `.claimed` and `.amount` reuse the derived slot key.

### `claimedCount` (Patterns T, W, X, Y, U)

- **T/W/X/Y:** same loop transform as `totalUnclaimed`
- **U:** `hasClaimed[recipients[i]] == true` → `hasClaimed[recipients[i]]`
- `count = count + 1` inside inner branch → `unchecked { ++count }` (bounded by `len`)

### `isRecipient` (Pattern Q — O(n) → O(1))

Original does a full linear scan of `recipients[]`. `isRegistered[user]` is set `true` whenever `user` is pushed into `recipients[]` and is never unset, making it an exact O(1) equivalent. Replaced with `return isRegistered[user]`.  
**Gas impact:** Drops from O(n) SLOADs to a single SLOAD regardless of recipient count.

### `recipientCount` / `remainingFor` (Patterns T, U)

- `public` → `external`; `hasClaimed[user] == true` → `hasClaimed[user]`

---

## StakingPool.sol

### State variables

| Variable | Before | After | Rationale |
|----------|--------|-------|-----------|
| `name` | `string public` | `string public constant` | Never reassigned |
| `symbol` | `string public` | `string public constant` | Never reassigned |
| `rewardRateBps` | `uint256 public` (storage) | **unchanged** | Reassigned in `setRewardRate` — cannot be immutable |
| `bonusRateBps` | `uint256 public` (storage) | `uint256 public immutable` | No setter exists; set to 100 in constructor |
| `maxStakers` | `uint256 public` (storage) | `uint256 public constant` | Never reassigned, never used in runtime logic |
| `owner` | `address public` (storage) | `address public immutable` | Set only in constructor |

### `onlyOwner` modifier (Pattern A)

`require(msg.sender == owner, long string)` → `if (msg.sender != owner) revert NotOwner()`

### `stake` (Patterns T, A, Y, U)

- `public` → `external`; all three `require` strings → custom errors; `tier = 0` → `uint256 tier`; `hasStaked[msg.sender] == false` → `!hasStaked[msg.sender]`

### `batchStake` (Patterns T, S, X, Y, Q, A, U)

- **S:** Both array params `memory` → `calldata`
- **Q (high value):** `totalStaked` read+written inside every iteration → cached to `_totalStaked`, one SLOAD before and one SSTORE after. Saves `(N-1)` warm SSTOREs per call.
- **X:** `len = users.length` hoisted; `unchecked { ++i }` on all loop exit paths (including `continue` branches)
- **Y/U:** `tier = 0` → `uint256 tier`; `isBlacklisted[user] == true` → `isBlacklisted[user]`; `stakes[user].active == true` → `stakes[user].active`; `hasStaked[user] == false` → `!hasStaked[user]`

### `unstake` (Patterns T, A)

- `public` → `external`; long `require` string → `revert NoActiveStake()`

### `distributeRewards` (Patterns T, X, Y, Q, U)

The hottest function — called once per distribution over all stakers.

- **Q (high value):** `rewardRateBps` is SLOADed inside the original loop every iteration. Now read once into `uint256 _rate` before the loop. For N stakers, saves N warm SLOADs (~100 gas each; ~10 000 gas on 100 stakers).
- **Q:** `bonusRateBps` is now `immutable` (free read from bytecode) — no SLOAD at all.
- **Q:** `stakers[i]` cached to `address s`; `StakeInfo storage si = stakes[s]` pointer avoids re-deriving the mapping slot for `active`, `amount`, and `tier`. `si.amount` cached to `uint256 amt` so it's read once even when `tier == 2`.
- **X:** `len = stakers.length` hoisted; `unchecked { ++i }`
- **Y:** `uint256 bonus = 0` → `uint256 bonus`; `uint256 i = 0` → `uint256 i`
- **U:** `stakes[s].active == true` → `si.active`

### `recomputeAll` (Patterns T, X, Y, Q)

- `rewardRateBps` hoisted to `_rate` before loop; `stakers[i]` cached to `s`; `len` hoisted; `unchecked { ++i }`

### `claim` (Patterns T, A)

- `public` → `external`; `require(amount > 0, ...)` → `if (amount == 0) revert NoRewards()`

### `totalRewards` (Patterns T, W, X, Y, Q)

Named return; `len` hoisted; `stakers[i]` only indexed once per iteration; `unchecked { ++i }`

### `activeStakerCount` (Patterns T, W, X, Y, U, Q)

- Same loop transforms; `== true` dropped; `++count` in `unchecked` block (bounded by `len`)

### `topStaker` (Patterns T, W, X, Y, Q)

- Named return; `maxAmount` replaces `uint256 max = 0`; `stakers[i]` cached to `addr`; `StakeInfo storage si` pointer so `si.active` and `si.amount` read from one resolved slot key; `unchecked { ++i }`

### `isStaker` (Pattern Q — O(n) → O(1))

Original scans `stakers[]` linearly. `hasStaked[user]` is set `true` on first stake/batchStake and `false` on `removeStaker`, keeping it exactly in sync with array membership. Replaced with `return hasStaked[user]`.

### `removeStaker` (Patterns T, A, Y, X, Q)

- `public` → `external`; both `require` strings → custom errors
- `uint256 index = 0; bool found = false` → `uint256 index; bool found` (Pattern Y)
- First scan loop: `len` hoisted; `unchecked { ++i }` on non-break path
- Shift loop: `unchecked { ++j }`; `stakers.length` read resolved from cached `len`
- `StakeInfo storage si = stakes[user]`: one storage pointer for `si.active`, `si.amount`, `si.active = false`, `si.exists = false` — avoids re-deriving the mapping slot four times

### `blacklist` / `stakerCount` / `setRewardRate` (Patterns T, A)

- `public` → `external`; `setRewardRate` long `require` → `if (newRateBps > 10000) revert RateTooHigh()`

---

## Gas impact summary (qualitative)

| Category | Estimated per-call saving |
|----------|--------------------------|
| `constant` / `immutable` config vars (Airdrop) | ~2100 gas per cold read eliminated (owner, name, claimFeeBps) |
| `constant` / `immutable` config vars (StakingPool) | ~2100 gas per cold read eliminated (owner, name, symbol, bonusRateBps, maxStakers) |
| Custom errors (both contracts) | ~200–400 gas per revert (no ABI string encoding); smaller bytecode |
| `calldata` vs. `memory` (setAllocations, batchStake) | ~3 gas/byte of calldata not copied into memory |
| `totalAllocated` hoisted (setAllocations, N users) | saves `(N−1) × ~2900` gas per call |
| `totalStaked` hoisted (batchStake, N users) | saves `(N−1) × ~2900` gas per call |
| `rewardRateBps` hoisted (distributeRewards, N stakers) | saves `N × ~100` warm-SLOAD gas per call |
| Loop counter (`unchecked ++i` vs `i++`) | ~25–30 gas per loop iteration |
| Array length cache | ~100 gas per iteration (eliminates dynamic-array length SLOAD) |
| `isRecipient` / `isStaker` O(1) rewrite | from O(n) SLOADs to 1 SLOAD; biggest relative win on large arrays |
| `public` → `external` | ~24 gas per call (eliminates internal calldata copy check) |

---

## Notes for test suite

1. **Custom errors:** Both test suites use bare `vm.expectRevert()` with no selector argument, so they are fully compatible with custom errors as written.
2. **`calldata` params:** Callers pass Solidity `memory` arrays to `setAllocations`/`batchStake`; the ABI encoding is identical, so no test changes are required.
3. **`isRecipient` / `isStaker`:** The O(1) mapping substitution is semantically identical for all reachable states — verified by inspection of all write sites.
4. **`bonusRateBps` as `immutable`:** The value is now set in the constructor and cannot be changed at runtime. If a setter is ever needed, it must be reverted to a storage variable.
5. **Original files untouched:** `src/Airdrop.sol` and `src/StakingPool.sol` are unchanged. Only `optimized/src/` contains the generated artifacts.
