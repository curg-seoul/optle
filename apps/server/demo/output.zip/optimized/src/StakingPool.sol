// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract StakingPool {
    // Pattern A: custom errors
    error NotOwner();
    error LengthMismatch();
    error ZeroAmount();
    error AlreadyActive();
    error Blacklisted();
    error NoActiveStake();
    error NoRewards();
    error RateTooHigh();
    error NotAStaker();
    error StakerNotFound();

    // Pattern R: constant/immutable — live in bytecode, no SLOAD per read
    string public constant name = "Naive Staking Pool";
    string public constant symbol = "NSP";
    // rewardRateBps is reassigned in setRewardRate — must remain a storage variable
    uint256 public rewardRateBps = 500;
    // bonusRateBps has no setter — safe to make immutable
    uint256 public immutable bonusRateBps;
    uint256 public constant maxStakers = 1000;
    address public immutable owner;

    // Storage layout preserved byte-for-byte (Level 1 — no struct repacking)
    struct StakeInfo {
        uint256 amount;
        uint256 since;
        bool active;
        address staker;
        uint256 tier;
        bool exists;
    }

    mapping(address => StakeInfo) public stakes;
    mapping(address => uint256) public rewards;
    mapping(address => bool) public hasStaked;
    mapping(address => bool) public isBlacklisted;
    mapping(address => bool) public hasClaimed;
    address[] public stakers;

    uint256 public totalStaked;
    uint256 public totalRewardsPaid;

    event Staked(address indexed user, uint256 amount);
    event Unstaked(address indexed user, uint256 amount);
    event RewardsClaimed(address indexed user, uint256 amount);
    event StakerRemoved(address indexed user);

    constructor() {
        owner = msg.sender;
        bonusRateBps = 100;
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner(); // Pattern A
        _;
    }

    // Patterns T, A, Y (no default init for tier), U (drop == false)
    function stake(uint256 amount) external {
        if (amount == 0) revert ZeroAmount();
        if (stakes[msg.sender].active) revert AlreadyActive();
        if (isBlacklisted[msg.sender]) revert Blacklisted();

        uint256 tier;
        if (amount >= 100000) {
            tier = 2;
        } else if (amount >= 1000) {
            tier = 1;
        }

        stakes[msg.sender] = StakeInfo({
            amount: amount,
            since: block.timestamp,
            active: true,
            staker: msg.sender,
            tier: tier,
            exists: true
        });

        if (!hasStaked[msg.sender]) {
            hasStaked[msg.sender] = true;
            stakers.push(msg.sender);
        }

        totalStaked = totalStaked + amount;
        emit Staked(msg.sender, amount);
    }

    // Patterns T, S (calldata), X (cache len, unchecked ++i), Y, Q (hoist totalStaked), A, U
    function batchStake(address[] calldata users, uint256[] calldata amounts) external onlyOwner {
        uint256 len = users.length;
        if (len != amounts.length) revert LengthMismatch();
        uint256 _totalStaked = totalStaked; // Pattern Q: single SLOAD, single SSTORE
        for (uint256 i; i < len;) {
            address user = users[i];
            if (isBlacklisted[user]) {
                unchecked { ++i; }
                continue;
            }
            if (stakes[user].active) {
                unchecked { ++i; }
                continue;
            }
            uint256 amt = amounts[i];
            uint256 tier;
            if (amt >= 100000) {
                tier = 2;
            } else if (amt >= 1000) {
                tier = 1;
            }
            stakes[user] = StakeInfo({
                amount: amt,
                since: block.timestamp,
                active: true,
                staker: user,
                tier: tier,
                exists: true
            });
            if (!hasStaked[user]) {
                hasStaked[user] = true;
                stakers.push(user);
            }
            _totalStaked = _totalStaked + amt;
            emit Staked(user, amt);
            unchecked { ++i; }
        }
        totalStaked = _totalStaked;
    }

    // Patterns T, A
    function unstake() external {
        if (!stakes[msg.sender].active) revert NoActiveStake();
        uint256 amount = stakes[msg.sender].amount;
        stakes[msg.sender].active = false;
        stakes[msg.sender].amount = 0;
        totalStaked = totalStaked - amount;
        emit Unstaked(msg.sender, amount);
    }

    // Patterns T, X (cache len, unchecked ++i), Y, Q (cache stakers[i], hoist rewardRateBps SLOAD),
    // U (drop == true). bonusRateBps is immutable — no SLOAD, read inline.
    function distributeRewards() external onlyOwner {
        uint256 len = stakers.length;
        uint256 _rate = rewardRateBps; // Pattern Q: one SLOAD for N iterations
        for (uint256 i; i < len;) {
            address s = stakers[i]; // Pattern Q: cache array element read
            StakeInfo storage si = stakes[s];
            if (si.active) {
                uint256 amt = si.amount;
                uint256 base = (amt * _rate) / 10000;
                uint256 bonus;
                if (si.tier == 2) {
                    bonus = (amt * bonusRateBps) / 10000; // immutable — free read
                }
                rewards[s] = rewards[s] + base + bonus;
            }
            unchecked { ++i; }
        }
    }

    // Patterns T, X, Y, Q (cache stakers[i], hoist rewardRateBps)
    function recomputeAll() external onlyOwner {
        uint256 len = stakers.length;
        uint256 _rate = rewardRateBps;
        for (uint256 i; i < len;) {
            address s = stakers[i];
            rewards[s] = (stakes[s].amount * _rate) / 10000;
            unchecked { ++i; }
        }
    }

    // Patterns T, A
    function claim() external {
        uint256 amount = rewards[msg.sender];
        if (amount == 0) revert NoRewards();
        rewards[msg.sender] = 0;
        hasClaimed[msg.sender] = true;
        totalRewardsPaid = totalRewardsPaid + amount;
        emit RewardsClaimed(msg.sender, amount);
    }

    // Patterns T, W, X, Y, Q (cache stakers[i])
    function totalRewards() external view returns (uint256 total) {
        uint256 len = stakers.length;
        for (uint256 i; i < len;) {
            total = total + rewards[stakers[i]];
            unchecked { ++i; }
        }
    }

    // Patterns T, W, X, Y, U, Q (cache stakers[i])
    function activeStakerCount() external view returns (uint256 count) {
        uint256 len = stakers.length;
        for (uint256 i; i < len;) {
            if (stakes[stakers[i]].active) {
                unchecked { ++count; }
            }
            unchecked { ++i; }
        }
    }

    // Patterns T, W, X, Y, Q (cache stakers[i] + storage pointer for si)
    function topStaker() external view returns (address top) {
        uint256 maxAmount;
        uint256 len = stakers.length;
        for (uint256 i; i < len;) {
            address addr = stakers[i];
            StakeInfo storage si = stakes[addr];
            if (si.active && si.amount > maxAmount) {
                maxAmount = si.amount;
                top = addr;
            }
            unchecked { ++i; }
        }
    }

    // Pattern Q: replace O(n) array scan with O(1) mapping lookup.
    // hasStaked[user] is set true on stake/batchStake and false on removeStaker,
    // keeping it in sync with membership in stakers[].
    function isStaker(address user) external view returns (bool) {
        return hasStaked[user];
    }

    // Patterns T, A, Y, X, Q (cache storage pointer for stakes[user])
    function removeStaker(address user) external onlyOwner {
        if (!hasStaked[user]) revert NotAStaker();
        uint256 len = stakers.length;
        uint256 index;
        bool found;
        for (uint256 i; i < len;) {
            if (stakers[i] == user) {
                index = i;
                found = true;
                break;
            }
            unchecked { ++i; }
        }
        if (!found) revert StakerNotFound();

        for (uint256 j = index; j < len - 1;) {
            stakers[j] = stakers[j + 1];
            unchecked { ++j; }
        }
        stakers.pop();

        StakeInfo storage si = stakes[user]; // Pattern Q: one storage pointer for multiple reads/writes
        if (si.active) {
            totalStaked = totalStaked - si.amount;
        }
        hasStaked[user] = false;
        si.active = false;
        si.exists = false;
        rewards[user] = 0;
        emit StakerRemoved(user);
    }

    // Pattern T
    function blacklist(address user) external onlyOwner {
        isBlacklisted[user] = true;
    }

    // Patterns T, A
    function setRewardRate(uint256 newRateBps) external onlyOwner {
        if (newRateBps > 10000) revert RateTooHigh();
        rewardRateBps = newRateBps;
    }

    // Pattern T
    function stakerCount() external view returns (uint256) {
        return stakers.length;
    }
}
