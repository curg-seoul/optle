// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract Airdrop {
    // Pattern A: custom errors (4-byte selector vs. ABI-encoded string — saves deploy + revert gas)
    error NotOwner();
    error LengthMismatch();
    error ZeroAmount();
    error NotRegistered();
    error AlreadyClaimed();
    error NoAllocation();

    // Pattern R: constant/immutable — values live in bytecode, no SLOAD (~2100 gas) per read
    string public constant name = "Naive Airdrop Distributor";
    uint256 public constant claimFeeBps = 0;
    address public immutable owner;

    struct Allocation {
        uint256 amount;
        bool claimed;
        address recipient;
        uint256 updatedAt;
    }

    mapping(address => Allocation) public allocations;
    mapping(address => bool) public isRegistered;
    mapping(address => bool) public hasClaimed;
    address[] public recipients;

    uint256 public totalAllocated;
    uint256 public totalClaimed;

    event AllocationSet(address indexed user, uint256 amount);
    event Claimed(address indexed user, uint256 amount);

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner(); // Pattern A
        _;
    }

    // Patterns T (public→external), S (calldata avoids copy), X (cache length, unchecked ++i),
    // Y (no default init), Q (hoist totalAllocated SLOAD/SSTORE out of loop), A (custom errors)
    function setAllocations(address[] calldata users, uint256[] calldata amounts) external onlyOwner {
        uint256 len = users.length;
        if (len != amounts.length) revert LengthMismatch();
        uint256 _totalAllocated = totalAllocated; // Pattern Q: single SLOAD, single SSTORE
        for (uint256 i; i < len;) {
            address user = users[i];
            uint256 amt = amounts[i];
            if (amt == 0) revert ZeroAmount();
            if (!isRegistered[user]) {
                isRegistered[user] = true;
                recipients.push(user);
            }
            allocations[user] = Allocation({
                amount: amt,
                claimed: false,
                recipient: user,
                updatedAt: block.timestamp
            });
            _totalAllocated = _totalAllocated + amt;
            emit AllocationSet(user, amt);
            unchecked { ++i; } // Pattern X
        }
        totalAllocated = _totalAllocated;
    }

    // Patterns T, A, U (drop redundant == false / == true comparisons)
    function claim() external {
        if (!isRegistered[msg.sender]) revert NotRegistered();
        if (hasClaimed[msg.sender]) revert AlreadyClaimed();
        uint256 amount = allocations[msg.sender].amount;
        if (amount == 0) revert NoAllocation();
        hasClaimed[msg.sender] = true;
        allocations[msg.sender].claimed = true;
        totalClaimed = totalClaimed + amount;
        emit Claimed(msg.sender, amount);
    }

    // Patterns T, W (named return drops local+explicit return), X, Y, Q (cache recipients[i])
    function totalUnclaimed() external view returns (uint256 total) {
        uint256 len = recipients.length;
        for (uint256 i; i < len;) {
            address r = recipients[i]; // Pattern Q: read array element once
            Allocation storage a = allocations[r];
            if (!a.claimed) {
                total = total + a.amount;
            }
            unchecked { ++i; }
        }
    }

    // Patterns T, W, X, Y, U
    function claimedCount() external view returns (uint256 count) {
        uint256 len = recipients.length;
        for (uint256 i; i < len;) {
            if (hasClaimed[recipients[i]]) {
                unchecked { ++count; }
            }
            unchecked { ++i; }
        }
    }

    // Pattern Q: replace O(n) linear scan with O(1) mapping lookup.
    // isRegistered[user] is set true whenever user is pushed to recipients[] and is never unset,
    // so it is the canonical O(1) equivalent of the original array scan.
    function isRecipient(address user) external view returns (bool) {
        return isRegistered[user];
    }

    // Pattern T
    function recipientCount() external view returns (uint256) {
        return recipients.length;
    }

    // Patterns T, U
    function remainingFor(address user) external view returns (uint256) {
        if (hasClaimed[user]) return 0;
        return allocations[user].amount;
    }
}
